package com.example.calendarreceiveeventchange;

import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.os.Bundle;
import android.provider.CalendarContract.Calendars;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

public class EditActivity extends Activity implements OnCheckedChangeListener {

	private boolean isEdit = false;
	private DatePicker start, end;
	private TimePicker startTime, endTime;
	private CheckBox allDay, none, day, week, month, year;

	private final int NONE = 0;
	private final int DAILY = 1;
	private final int WEEKLY = 2;
	private final int MONTHLY = 3;
	private final int YEARLY = 4;

	private int recurrent = NONE;
	private String all = "0";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit);
		final TextView event = (TextView) this.findViewById(R.id.edt_event);
		final TextView des = (TextView) this.findViewById(R.id.edt_des);
		final TextView loc = (TextView) this.findViewById(R.id.edt_loc);
		Button save = (Button) this.findViewById(R.id.btn_save);
		Button cancel = (Button) this.findViewById(R.id.btn_cancel);
		Button delete = (Button) this.findViewById(R.id.btn_delete);
		start = (DatePicker) this.findViewById(R.id.pick_start);
		end = (DatePicker) this.findViewById(R.id.pick_end);

		startTime = (TimePicker) this.findViewById(R.id.pick_start_time);
		endTime = (TimePicker) this.findViewById(R.id.pick_end_time);

		allDay = (CheckBox) this.findViewById(R.id.check_allDay);
		none = (CheckBox) this.findViewById(R.id.check_none);
		day = (CheckBox) this.findViewById(R.id.check_daily);
		week = (CheckBox) this.findViewById(R.id.check_week);
		month = (CheckBox) this.findViewById(R.id.check_month);
		year = (CheckBox) this.findViewById(R.id.check_year);

		allDay.setOnCheckedChangeListener(this);
		none.setOnCheckedChangeListener(this);
		day.setOnCheckedChangeListener(this);
		week.setOnCheckedChangeListener(this);
		month.setOnCheckedChangeListener(this);
		year.setOnCheckedChangeListener(this);

		save.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (event.getText().toString().equalsIgnoreCase("")
						|| des.getText().toString().equalsIgnoreCase("")
						|| loc.getText().toString().equalsIgnoreCase(""))
					return;

				if (isEdit) {
					EventConstants.e.title = event.getText().toString();
					EventConstants.e.description = des.getText().toString();
					EventConstants.e.location = loc.getText().toString();
					if (EventManager.getInstance().updateCalendarEvent(
							EventConstants.e) == 0) {
						Log.i("error", "edit fail");
					}
				} else {
					EventData e = new EventData();
					e.title = event.getText().toString();
					e.description = des.getText().toString();
					e.location = loc.getText().toString();

					e.allDay = all;
					Calendar calendar = Calendar.getInstance();
					if (e.allDay.equalsIgnoreCase("1")) {
						calendar.set(start.getYear(), start.getMonth(),
								start.getDayOfMonth(), 7, 0, 0);
						e.start = calendar.getTime().getTime();

						calendar.set(end.getYear(), end.getMonth(),
								end.getDayOfMonth(), 7, 0, 0);
						e.end = calendar.getTime().getTime() + 86400000;
					} else {
						calendar.set(start.getYear(), start.getMonth(),
								start.getDayOfMonth(),
								startTime.getCurrentHour(),
								startTime.getCurrentMinute(), 0);
						e.start = calendar.getTime().getTime();

						calendar.set(end.getYear(), end.getMonth(),
								end.getDayOfMonth(), endTime.getCurrentHour(),
								endTime.getCurrentMinute(), 0);
						e.end = calendar.getTime().getTime();
					}

					if (recurrent != NONE) {

						e.end = 0;
						e.duration = "P" + ((e.end - e.start) / 1000) + "S";
						calendar.setTimeInMillis(e.start);
						int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
						String rule = "FREQ=";
						if (recurrent == DAILY)
							rule += "DAILY;COUNT=30";
						else if (recurrent == WEEKLY) {
							rule += "WEEKLY;INTERVAL=1;COUNT=30";
							if (calendar.get(Calendar.MONDAY) == dayOfWeek)
								rule += ";BYDAY=MO";
							else if (calendar.get(Calendar.TUESDAY) == dayOfWeek)
								rule += ";BYDAY=TU";
							else if (calendar.get(Calendar.WEDNESDAY) == dayOfWeek)
								rule += ";BYDAY=WE";
							else if (calendar.get(Calendar.THURSDAY) == dayOfWeek)
								rule += ";BYDAY=TH";
							else if (calendar.get(Calendar.FRIDAY) == dayOfWeek)
								rule += ";BYDAY=FR";
							else if (calendar.get(Calendar.SATURDAY) == dayOfWeek)
								rule += ";BYDAY=SA";
							else if (calendar.get(Calendar.SUNDAY) == dayOfWeek)
								rule += ";BYDAY=SU";
						} else if (recurrent == MONTHLY) {
							rule += "MONTHLY;INTERVAL=1;COUNT=20;BYMONTHDAY="
									+ calendar.get(Calendar.DAY_OF_MONTH);
						} else if (recurrent == YEARLY)
							rule += "YEARLY;INTERVAL=1;COUNT=10;BYMONTH="
									+ (calendar.get(Calendar.MONTH) + 1)
									+ ";BYMONTHDAY="
									+ calendar.get(Calendar.DAY_OF_MONTH);

						e.rRule = rule;
					}
					e.timeZone = EventConstants.CURRENT_TIMEZONE;
					e.calendarId = EventManager.getInstance().getCalendarId(
							"gts8899@gmail.com");
					if (EventManager.getInstance().addCalendarEvent(e) == 0) {
						Log.i("error", "add fail");
					}
				}
				EventConstants.e = null;
				finish();
			}
		});

		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				EventConstants.e = null;
				finish();
			}
		});

		delete.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!isEdit)
					return;
				if (EventManager.getInstance().deleteCalendarEvent(
						EventConstants.e.eventId) == 0)
					Log.i("error", "delete fail");
				EventConstants.e = null;
				finish();
			}
		});

		if (EventConstants.e == null) {
			isEdit = false;
		} else {
			isEdit = true;
			event.setText(EventConstants.e.title);
			des.setText(EventConstants.e.description);
			loc.setText(EventConstants.e.location);
		}

	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (buttonView.getId() == R.id.check_allDay) {
			all = isChecked ? "1" : "0";
			startTime.setEnabled(!isChecked);
			endTime.setEnabled(!isChecked);
		} else if (isChecked) {
			if (buttonView.getId() == R.id.check_none) {
				day.setChecked(!isChecked);
				week.setChecked(!isChecked);
				month.setChecked(!isChecked);
				year.setChecked(!isChecked);
				recurrent = NONE;
			} else if (buttonView.getId() == R.id.check_daily) {
				none.setChecked(!isChecked);
				week.setChecked(!isChecked);
				month.setChecked(!isChecked);
				year.setChecked(!isChecked);
				recurrent = DAILY;
			} else if (buttonView.getId() == R.id.check_week) {
				none.setChecked(!isChecked);
				day.setChecked(!isChecked);
				month.setChecked(!isChecked);
				year.setChecked(!isChecked);
				recurrent = WEEKLY;
			} else if (buttonView.getId() == R.id.check_month) {
				none.setChecked(!isChecked);
				day.setChecked(!isChecked);
				week.setChecked(!isChecked);
				year.setChecked(!isChecked);
				recurrent = MONTHLY;
			} else if (buttonView.getId() == R.id.check_year) {
				none.setChecked(!isChecked);
				day.setChecked(!isChecked);
				week.setChecked(!isChecked);
				month.setChecked(!isChecked);
				recurrent = YEARLY;
			}
		}

	}

}
