package com.example.calendarreceiveeventchange;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

@SuppressLint({ "InlinedApi", "NewApi" })
public class MainActivity extends Activity {

	ArrayList<EventData> events;
	EventListAdapter adapter;
	ListView list;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		list = (ListView) findViewById(R.id.list_event);
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				EventData e = events.get(arg2);
				EventConstants.e = e;
				Intent i = new Intent(getApplicationContext(), EditActivity.class);
				startActivity(i);
			}
			
		});
		
		Button add = (Button) findViewById(R.id.btn_add);
		add.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				EventConstants.e = null;
				Intent i = new Intent(getApplicationContext(), EditActivity.class);
				startActivity(i);
			}
		});
		
		EventManager.getInstance().ctx = this;
		EventManager.getInstance().getAccounts();
		EventManager.getInstance().getCalendarList();
	}
	
	
	private class EventListAdapter extends BaseAdapter {
		
		ArrayList<EventData> events;
		Context ctx;
		ArrayList<View> views = new ArrayList<View>();
		
		public EventListAdapter(ArrayList<EventData> data, Context context) {
			this.events = data;
			this.ctx = context;
			createViews();
		}

		@Override
		public int getCount() {
			return events.size();
		}

		@Override
		public Object getItem(int position) {
			return events.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}
		
		@Override
		public void notifyDataSetChanged() {
			super.notifyDataSetChanged();
			createViews();
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			return views.get(position);
		}
		
		private void createViews() {
			views.clear();
			for (EventData e : events) {
				LayoutInflater infalInflater = (LayoutInflater) ctx
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				View v = infalInflater.inflate(R.layout.event_item, null);
				
				TextView event = (TextView) v.findViewById(R.id.tv_event);
				TextView start = (TextView) v.findViewById(R.id.tv_start);
				TextView end = (TextView) v.findViewById(R.id.tv_end);
				TextView des = (TextView) v.findViewById(R.id.tv_des);
				TextView location = (TextView) v.findViewById(R.id.tv_location);
				
				event.setText(e.title);
				start.setText(EventManager.getInstance().getDate(e.start));
				end.setText(EventManager.getInstance().getDate(e.end));
				des.setText(e.description);
				location.setText(e.location);
				
				views.add(v);
			}
		}
		
	}

	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		events = EventManager.getInstance().readCalendarEvent();
		if (adapter == null) {
			adapter = new EventListAdapter(events, this);	
			list.setAdapter(adapter);
		} else
			adapter.notifyDataSetChanged();
	}

}
